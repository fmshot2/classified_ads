## EFContact

```php
composer install
```

### API ENDPOINTS

**_ Get all services _**

`/api/v1/services`

**_ Get a service _**

`/api/v1/services/{id}`

**_ Get all categories _**

`/api/v1/categories`

**_ Search for a service _**

`/api/v1/search/{query}`

**_ Get all sliders _**

`/api/v1/banners/sliders`
